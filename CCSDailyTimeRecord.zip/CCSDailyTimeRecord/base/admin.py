from django.contrib import admin
from .models import userTime

# Register your models here.
admin.site.register(userTime)
